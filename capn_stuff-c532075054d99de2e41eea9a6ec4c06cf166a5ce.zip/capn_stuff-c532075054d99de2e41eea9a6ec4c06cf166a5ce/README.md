# capn_stuff
this support the capn package in R.
This problem set is designed for students with no experience in R, but who are familar with Fenichel et al. 2016 PNAS http://www.pnas.org/content/113/9/2382.short 

capN and groundwater exercise.pdf is the actual problem set.
groundwater_capn.R is an R script students will need to do the problem set.
my_gw_data.RData stored a dataset for the exercise, but groundwater_capn.R pulls this from Github automatically, so don't worry about it.

